# High-level actions
# The angle is ordered by [DOWN, RIGHT, UP, LEFT]
# UP=2
# DOWN=0
# LEFT=3
# RIGHT=1
UP=1
DOWN=-1
LEFT=2
RIGHT=0

# Primitive actions
FORWARD=4
LEFT_TURN=5
RIGHT_TURN=6

# Imitation Learning using Dataset Aggregation

## Introduction
In this baseline we train a small squeezenet model on expert trajectories to simply clone the behaviour of the expert.
Using only the expert trajectories would result in a model unable to recover from non-optimal positions ,Hence we use a technique called DAgger a dataset aggregation technique with mixed policies between expert and model.
This technique of random mixing would help the model learn a more general trajectory than the optimal one provided by the expert alone.

## Quickstart
1) Clone this [repo](https://github.com/duckietown/gym-duckietown):

    $ git clone https://github.com/duckietown/gym-duckietown.git

2) Change into the directory:

    $ cd gym-duckietown

3) Install the package:

    $ pip3 install -e .

4) Start training:

    $ python -m learning.imitation.iil-dagger.train

5) Test the trained agent specifying the saved model:

    $ python -m learning.imitation.pytorch-v2.test --model-path ![path]


#!/bin/bash

python --version

python -c "import numpy; print numpy.__version__"

python -c "import rosbag"
python -c "import rosbag"

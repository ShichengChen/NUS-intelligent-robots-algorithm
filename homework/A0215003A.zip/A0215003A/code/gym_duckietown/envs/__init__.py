# coding=utf-8
# noinspection PyUnresolvedReferences
from gym_duckietown.wrappers import DiscreteWrapper
from gym_duckietown.envs.duckietown_env import DuckietownEnv
from gym_duckietown.envs.duckiebot_env import DuckiebotEnv
from gym_duckietown.envs.multimap_env import MultiMapEnv
